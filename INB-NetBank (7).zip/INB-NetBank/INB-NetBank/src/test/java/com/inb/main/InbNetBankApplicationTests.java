package com.inb.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InbNetBankApplicationTests {

	@Test
	void contextLoads() {
	}

}
